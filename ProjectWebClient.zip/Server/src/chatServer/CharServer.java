package chatServer;

import network.TCPConnection;
import network.TCPConnectionListener;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;

public class CharServer implements TCPConnectionListener {
    public static void main (String args[]){
        new CharServer();
    }

    private final ArrayList<TCPConnection> connections = new ArrayList<>();

    private CharServer(){
        System.out.println("Сервер работает!");
        try {
            //ServerSocket serverSocket = new ServerSocket(4845);
            ServerSocket serverSocket = new ServerSocket(16300);
            while(true) {
                try{
                    new TCPConnection(this, serverSocket.accept());
                }catch (IOException e){
                    System.out.println("ошибка" + e);
                }
            }
        }catch (IOException e){
            throw new RuntimeException(e);
        }
    }


    @Override
    public synchronized void onConnectionReady(TCPConnection tcpConnection) {
        connections.add(tcpConnection);
        sendAllConnections("Client connected: " + tcpConnection);
    }

    @Override
    public synchronized void onReceiveString(TCPConnection tcpConnection, String value) {
        sendAllConnections(value);
    }

    @Override
    public synchronized void onDisconnect(TCPConnection tcpConnection) {
        connections.remove(tcpConnection);
        sendAllConnections("Client disconnected: " + tcpConnection);
    }

    @Override
    public synchronized void onExceptions(TCPConnection tcpConnection, Exception e) {
        System.out.println("ОШИБКА: " + e);
    }

    private void sendAllConnections(String value){
        System.out.println(value);
        final int cnt = connections.size();
        for (int i = 0; i < cnt; i++) {
            connections.get(i).sendString(value);
        }
    }
}
